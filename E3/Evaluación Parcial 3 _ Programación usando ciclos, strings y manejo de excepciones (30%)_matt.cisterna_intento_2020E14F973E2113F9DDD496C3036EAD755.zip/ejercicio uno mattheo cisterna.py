#ejercicio uno - mattheo cisterna 
# Contadores 
titulares = 0
asociados = 0

# validar cantidad de profesores 
while True:
    try:
        cantidad = int(input("Ingrese la cantidad de profesores: "))
        if cantidad > 0:
            break
        else:
            print("Cantidad inválida! Ingresa un entero positivo para continuar.")
    except ValueError:
        print("Cantidad inválida! Ingresa un entero positivo para continuar.")

# registro de profesores 
for i in range(cantidad):
    print(f"\nProfesor {i + 1}")

    # validar codigo docente 
    while True:
        codigo = input("Ingrese código docente: ")
        if len(codigo) >= 6 and " " not in codigo:
            break
        else:
            print("Código inválido. Debe tener al menos 6 caracteres y no contener espacios")

    # validar horas catedra
    while True:
        try:
            horas = int(input("Ingrese horas cátedra: "))
            if horas > 0:
                break
            else:
                print("¡Error académico! Ingresa un número entero positivo.")
        except ValueError:
            print("¡Error académico! Ingresa un número entero positivo.")

    # Clasificación 
    if horas > 60:
        print("Clasificación: Profesor titular")
        titulares += 1
    else:
        print("Clasificación: Profesor asociado")
        asociados += 1

# resumen final
print("\n--- Resumen final ---")
print(f"La universidad cuenta con {titulares} profesores titulares y {asociados} profesores asociados. ¡Clases programadas!")